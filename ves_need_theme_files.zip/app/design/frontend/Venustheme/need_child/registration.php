<?php
/**
 * Copyright © 2016 Venustheme. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::THEME,
    'frontend/Venustheme/need_child',
    __DIR__
);
